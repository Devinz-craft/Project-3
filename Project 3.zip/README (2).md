# (Fordgobike Data Exploration )
## by (Daniel Obioha)


## Dataset

> This data set includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area.
The dataset consists of 183,412 rows and  20 columns

>Features :

>1- Member_Gender(Male,Female and Other)

>2- User Type (Subscriber or Customer )

>3- Trip Duration(in seconds)

>4- Bike ID

>5- Start Time and Date

>6- End Time and Date

>7- Start Station ID

>8- End Station ID

>9- Start Station Name

>10- End Station Name

>11- End Station Latitude

>12- End Station Longitude

>13- Start Station Latitude

>14- Start Station Longitude

>15-Member Birth Year

>16-Age

>17-Start Hour

>18-Day of the Week. etc


## Summary of Findings

> From general investigation its safe to say that if a cutomer who is female purchaces a bike for a trip on weekends the probability of the trip being long is very high.

> From the investigations , if a subscriber that purchased the bike is an other gender on weekend then the duration of the trip is likely to be very long .


## Key Insights for Presentation

> The weekend days (Sunday and Saturdays) are the least number of bike Trips.But it seems that at (Sunday and Saturdays) the trips duration is higher than for other weekdays.